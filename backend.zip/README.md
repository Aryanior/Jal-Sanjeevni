Backend: run `npm install` then `npm start`. Configure .env. Uses MySQL.
