// server.js
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Use a fallback secret key if .env missing
const JWT_SECRET = process.env.JWT_SECRET || "temp_secret_key";

// ✅ In-memory mock user list
const users = [
  {
    id: 1,
    name: "Public Demo",
    email: "public@example.com",
    password_hash: bcrypt.hashSync("Passw0rd!", 10),
    role: "public",
  },
  {
    id: 2,
    name: "Medic Demo",
    email: "mi_demo@example.com",
    password_hash: bcrypt.hashSync("Passw0rd!", 10),
    role: "hospital",
  },
  {
    id: 3,
    name: "Collector Demo",
    email: "gi_demo@example.com",
    password_hash: bcrypt.hashSync("Passw0rd!", 10),
    role: "collector",
  },
];

// ✅ LOGIN Endpoint
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());

  if (!user)
    return res.status(401).json({ error: "Invalid credentials — user not found" });

  const valid = bcrypt.compareSync(password, user.password_hash);
  if (!valid)
    return res.status(401).json({ error: "Invalid credentials — wrong password" });

  const token = jwt.sign(
    { id: user.id, role: user.role, email: user.email },
    JWT_SECRET,
    { expiresIn: "8h" }
  );

  console.log("🔐 Logged in:", user.email);
  res.json({ token, user });
});

// ✅ REGISTER Endpoint (mock)
app.post("/api/auth/register", (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: "missing_fields" });

  // Determine role from email prefix
  let role = "public";
  const lower = email.toLowerCase();
  if (lower.startsWith("mi")) role = "hospital";
  else if (lower.startsWith("gi")) role = "collector";

  // Prevent duplicate
  if (users.some((u) => u.email.toLowerCase() === lower))
    return res.status(409).json({ error: "email_exists" });

  // Add new user
  const newUser = {
    id: users.length + 1,
    name,
    email,
    password_hash: bcrypt.hashSync(password, 10),
    role,
  };
  users.push(newUser);

  console.log("🆕 Registered:", newUser.email, "| Role:", role);
  res.json({ ok: true, user: newUser });
});

// ✅ Mock Advertisement endpoint
app.get("/api/user/schemes", (req, res) => {
  res.json({
    schemes: [
      {
        id: 1,
        title: "Clean Water Awareness Drive 💧",
        description: "Join our mission for purified drinking water in every home.",
      },
      {
        id: 2,
        title: "Rainwater Harvesting Scheme 🌧️",
        description: "Government subsidy available for water conservation systems.",
      },
    ],
  });
});
// ---------- CHATBOT ENDPOINT ----------
const { exec } = require("child_process");

app.post("/api/chatbot", (req, res) => {
  const question = req.body.question;

  if (!question) {
    return res.status(400).json({ error: "Missing question" });
  }

  exec(
    `python chatbot_model/predict.py "${question.replace(/"/g, "'")}"`,
    (error, stdout, stderr) => {
      if (error) {
        console.error("Chatbot error:", error);
        return res.status(500).json({ error: "Chatbot failed" });
      }

      try {
        const response = JSON.parse(stdout);
        res.json({ answer: response.answer });
      } catch (e) {
        res.status(500).json({ error: "Invalid chatbot output" });
      }
    }
  );
});


// ✅ Fallback
app.get("/", (_, res) =>
  res.send("💧 Jal Sanjeevni backend running — mock mode active")
);

// ✅ Start Server
const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`✅ Mock backend running on port ${port}`));
