// main.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'screens/chat_screen.dart';

// ---------- CONFIG: change base if needed ----------
const String BASE_URL = 'http://192.168.29.87:4000'; // <-- your IPv4 and port

// ---------- IN-MEMORY FALLBACK DB (so demo works offline) ----------
class LocalDB {
  static List<Map<String, dynamic>> ads = [];
  static List<Map<String, dynamic>> cases = [];
  static List<Map<String, dynamic>> alerts = [];
  static List<Map<String, dynamic>> resourceRequests = [];
  static List<Map<String, dynamic>> allocations = [];
  static String tollFreeNumber = '';
  static List<Map<String, dynamic>> users = []; // simple user cache from register/login
}

// ---------- TRANSLATIONS & LANGUAGE PROVIDER ----------
final Map<String, Map<String, String>> _translations = {
  'English': {
    'app_name': 'Jal Sanjeevni',
    'home': 'Home',
    'medics': 'Medics',
    'government': 'Government',
    'profile': 'Profile',
    'login': 'Login',
    'register': 'Register',
    'email': 'Email / ID',
    'password': 'Password',
    'name': 'Name',
    'continue_public': 'Continue as Public',
    'choose_interface': 'Choose Interface',
    'public': 'Public',
    'medic': 'Medic',
    'government': 'Government',
    'report_case': 'Report Case',
    'post_ad': 'Post Advertisement (Schemes/Camps)',
    'ask_help': 'Ask Help (resources/staff)',
    'show_allocated': 'Show Allocated Resources & Staff',
    'alerts': 'Alerts',
    'trend_analysis': 'Trend Analysis (Cases over time)',
    'resource_allocation': 'Resource Allocation & Staff Appointment',
    'patient_distribution': 'Patient Distribution',
    'emergency_gen': 'Emergency Notification Generator',
    'water_test_results': 'Water Test Results',
    'send': 'Send',
    'fill_fields': 'Please fill required fields',
    'case_reported': 'Case reported',
    'ad_posted': 'Advertisement posted',
    'request_sent': 'Request sent',
    'help_allocated': 'Help allocated',
    'no_requests': 'No pending requests',
    'no_allocations': 'No allocations found',
    'no_cases': 'No cases yet',
    'good_habits_title': '5 Good Habits for Healthy Water',
    'habit1': 'Boil water before drinking.',
    'habit2': 'Store water in clean containers.',
    'habit3': 'Clean water tanks regularly.',
    'habit4': 'Avoid mixing wastewater with drinking sources.',
    'habit5': 'Report leaks and contamination immediately.',
    'ads': 'Live Health Advertisements',
    'toll_label': 'Toll-free number',
    'edit_toll': 'Edit Toll-free Number',
    'enter_toll': 'Enter number',
    'saved': 'Saved',
    'logout': 'Logout',
    'connection_error': 'Connection error',
    'login_failed': 'Login failed',
    'register_failed': 'Registration failed',
    'register_success': 'Registered successfully. Please login.',
    'signup_role_hint': 'Use MI... for medics, GI... for government, UI... for public',
    'return_home': 'Return to Main Page',
    'chatbot': 'Chatbot',
    'coming_soon': '🤖 Chatbot coming soon...',
  },
  'Hindi': {
    'app_name': 'जल संजीवनी',
    'home': 'होम',
    'medics': 'चिकित्सक',
    'government': 'सरकार',
    'profile': 'प्रोफ़ाइल',
    'login': 'लॉगिन',
    'register': 'रजिस्टर',
    'email': 'ईमेल / आईडी',
    'password': 'पासवर्ड',
    'name': 'नाम',
    'continue_public': 'जनता के रूप में जारी रखें',
    'choose_interface': 'इंटरफ़ेस चुनें',
    'public': 'जनता',
    'medic': 'चिकित्सक',
    'government': 'सरकार',
    'report_case': 'मामला रिपोर्ट करें',
    'post_ad': 'विज्ञापन पोस्ट करें (स्कीम/कैंप)',
    'ask_help': 'संसाधन/कर्मचारी के लिए मदद मांगें',
    'show_allocated': 'आवंटित संसाधन और स्टाफ दिखाएँ',
    'alerts': 'अलर्ट',
    'trend_analysis': 'ट्रेंड विश्लेषण (समय के साथ मामले)',
    'resource_allocation': 'संसाधन आवंटन और स्टाफ नियुक्ति',
    'patient_distribution': 'रोगी वितरण',
    'emergency_gen': 'आपातकालीन सूचना जनरेटर',
    'water_test_results': 'जल परीक्षण परिणाम',
    'send': 'भेजें',
    'fill_fields': 'कृपया आवश्यक फ़ील्ड भरें',
    'case_reported': 'मामला रिपोर्ट किया गया',
    'ad_posted': 'विज्ञापन पोस्ट किया गया',
    'request_sent': 'अनुरोध भेजा गया',
    'help_allocated': 'सहायता आवंटित की गई',
    'no_requests': 'कोई लंबित अनुरोध नहीं',
    'no_allocations': 'कोई आवंटन नहीं मिला',
    'no_cases': 'अभी कोई मामला नहीं',
    'good_habits_title': 'स्वस्थ पानी के लिए 5 अच्छी आदतें',
    'habit1': 'पीने से पहले पानी को उबालें।',
    'habit2': 'पानी को साफ कंटेनरों में रखें।',
    'habit3': 'पानी की टंकियों को नियमित रूप से साफ करें।',
    'habit4': 'गंदे पानी को पीने के स्रोतों के साथ मिलाने से बचें।',
    'habit5': 'लीकेज और प्रदूषण तुरंत रिपोर्ट करें।',
    'ads': 'लाइव स्वास्थ्य विज्ञापन',
    'toll_label': 'टोल-फ्री नंबर',
    'edit_toll': 'टोल-फ्री नंबर संपादित करें',
    'enter_toll': 'नंबर दर्ज करें',
    'saved': 'सहेजा गया',
    'logout': 'लॉग आउट',
    'chatbot': 'चैटबॉट',
    'coming_soon': '🤖 चैटबॉट जल्द आ रहा है...',
    'connection_error': 'कनेक्शन त्रुटि',
    'login_failed': 'लॉगिन विफल',
    'register_failed': 'पंजीकरण विफल',
    'register_success': 'सफलतापूर्वक रजिस्टर हुआ। कृपया लॉगिन करें।',
    'signup_role_hint': 'MI... के लिए चिकित्सक, GI... के लिए सरकार, UI... जनता के लिए',
    'return_home': 'मुख्य पृष्ठ पर लौटें',
  },
  'Bengali': {
    'app_name': 'জল সঞ্জীবনী',
    'home': 'হোম',
    'medics': 'চিকিৎসক',
    'government': 'সরকার',
    'profile': 'প্রোফাইল',
    'login': 'লগইন',
    'register': 'রেজিস্টার',
    'email': 'ইমেল / আইডি',
    'password': 'পাসওয়ার্ড',
    'name': 'নাম',
    'continue_public': 'সাধারণ ব্যবহারকারী হিসাবে চালিয়ে যান',
    'choose_interface': 'ইন্টারফেস নির্বাচন করুন',
    'public': 'সাধারণ',
    'medic': 'চিকিৎসক',
    'government': 'সরকার',
    'report_case': 'কেস রিপোর্ট করুন',
    'post_ad': 'বিজ্ঞাপন পোস্ট করুন (স্কিম/ক্যাম্প)',
    'ask_help': 'সম্পদ/কর্মী সহায়তা চাইুন',
    'show_allocated': 'বরাদ্দকৃত সম্পদ এবং কর্মী দেখান',
    'alerts': 'অ্যলার্ট',
    'trend_analysis': 'ট্রেন্ড বিশ্লেষণ (সময় ভিত্তিক কেস)',
    'resource_allocation': 'সম্পদ বরাদ্দ এবং কর্মী নিয়োগ',
    'patient_distribution': 'রোগী বিতরণ',
    'emergency_gen': 'জরুরি বিজ্ঞপ্তি জেনারেটর',
    'water_test_results': 'জল পরীক্ষার ফলাফল',
    'send': 'পাঠান',
    'fill_fields': 'অনুগ্রহ করে প্রয়োজনীয় ফিল্ড পূরণ করুন',
    'case_reported': 'কেস রিপোর্ট করা হয়েছে',
    'ad_posted': 'বিজ্ঞাপন পোস্ট করা হয়েছে',
    'request_sent': 'অনুরোধ পাঠানো হয়েছে',
    'help_allocated': 'সাহায্য বরাদ্দ করা হয়েছে',
    'no_requests': 'কোনও মুলতুবি অনুরোধ নেই',
    'no_allocations': 'কোনও বরাদ্দ পাওয়া যায়নি',
    'no_cases': 'এখনো কোনো কেস নেই',
    'good_habits_title': 'স্বাস্থ্যকর পানির জন্য ৫টি অভ্যাস',
    'habit1': 'পান করার আগে জল ফুটিয়ে নিন।',
    'habit2': 'জল পরিষ্কার পাত্রে সংরক্ষণ করুন।',
    'habit3': 'জল ট্যাংক নিয়মিত পরিষ্কার করুন।',
    'habit4': 'পানীয় জল এবং বর্জ্য জল মেশাবেন না।',
    'habit5': 'দূষণের রিপোর্ট সাথে সাথে দিন।',
    'ads': 'লাইভ স্বাস্থ্য বিজ্ঞাপন',
    'toll_label': 'টোল-ফ্রি নম্বর',
    'edit_toll': 'টোল-ফ্রি নম্বর সম্পাদন করুন',
    'enter_toll': 'নম্বর লিখুন',
    'saved': 'সংরক্ষণ করা হয়েছে',
    'logout': 'লগ আউট',
    'chatbot': 'চ্যাটবট',
    'coming_soon': '🤖 চ্যাটবট শীঘ্রই আসছে...',
    'connection_error': 'সংযোগ ত্রুটি',
    'login_failed': 'লগইন ব্যর্থ',
    'register_failed': 'রেজিস্ট্রেশন ব্যর্থ',
    'register_success': 'সফলভাবে রেজিস্টার করা হয়েছে। অনুগ্রহ করে লগইন করুন।',
    'signup_role_hint': 'MI... চিকিৎসকদের জন্য, GI... সরকার জন্য, UI... সাধারণ ব্যবহারকারী',
    'return_home': 'প্রাথমিক পৃষ্ঠায় ফিরে যান',
  },
};

class LanguageProvider extends ChangeNotifier {
  String _currentLanguage = 'English';
  String get currentLanguage => _currentLanguage;

  void changeLanguage(String language) {
    _currentLanguage = language;
    notifyListeners();
  }

  // ✅ Main translations getter
  Map<String, String> get translations {
    return _translations[_currentLanguage] ?? _translations['English']!;
  }

  // ✅ Alias for older code that uses `lang.t`
  Map<String, String> get t => translations;

  // ✅ Optional alias if code uses `current` instead of `currentLanguage`
  String get current => _currentLanguage;

  // ✅ Optional alias if code uses `setLanguage` instead of `changeLanguage`
  void setLanguage(String language) => changeLanguage(language);
}

// ---------- APP ENTRY ----------
void main() {
  runApp(const JalSanjeevniApp());
}

class JalSanjeevniApp extends StatelessWidget {
  const JalSanjeevniApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jal Sanjeevni',
      debugShowCheckedModeBanner: false,
      home: const InterfaceChoiceScreen(),
    );
  }
}

// ---------- INTERFACE CHOICE (Public / Medics / Gov) ----------
class InterfaceChoiceScreen extends StatefulWidget {
  const InterfaceChoiceScreen({super.key});

  @override
  State<InterfaceChoiceScreen> createState() => _InterfaceChoiceScreenState();
}

class _InterfaceChoiceScreenState extends State<InterfaceChoiceScreen> {
  final LanguageProvider lang = LanguageProvider();

  @override
  Widget build(BuildContext context) {
    final t = lang.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['choose_interface']!)),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(children: [
          const SizedBox(height: 12),
          _buildCard(context, t['public']!, Icons.public, Colors.blue, () {
            // Public: no login required, go direct to MainScreen with Public role
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        MainScreen(userType: 'Public', languageProvider: lang)));
          }),
          const SizedBox(height: 12),
          _buildCard(context, t['medic']!, Icons.medical_services, Colors.green,
              () {
            // Medics: must login/register
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        LoginScreen(expectedRole: 'hospital', languageProvider: lang)));
          }),
          const SizedBox(height: 12),
          _buildCard(context, t['government']!, Icons.account_balance, Colors.orange,
              () {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        LoginScreen(expectedRole: 'collector', languageProvider: lang)));
          }),
          const SizedBox(height: 24),
          Text(
            'Tip: ${lang.t['signup_role_hint']}',
            style: const TextStyle(color: Colors.grey),
          )
        ]),
      ),
    );
  }

  Widget _buildCard(BuildContext ctx, String title, IconData icon, Color color, VoidCallback onTap) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(title),
        trailing: const Icon(Icons.arrow_forward_ios, size: 18),
        onTap: onTap,
      ),
    );
  }
}

// ---------- LOGIN & REGISTER ----------
class LoginScreen extends StatefulWidget {
  final String expectedRole; // 'hospital' or 'collector' or leave empty/null to accept any
  final LanguageProvider languageProvider;
  const LoginScreen({super.key, required this.expectedRole, required this.languageProvider});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailC = TextEditingController();
  final TextEditingController passC = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    final t = widget.languageProvider.t;
    final email = emailC.text.trim();
    final pass = passC.text;
    if (email.isEmpty || pass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['fill_fields']!)));
      return;
    }

    setState(() => loading = true);
    try {
      final url = Uri.parse('$BASE_URL/api/auth/login');
      final res = await http.post(url,
          headers: {'Content-Type': 'application/json'},
          body: json.encode({'email': email, 'password': pass}));
      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        final role = data['user']['role'] as String? ?? 'user';
        // verify expected role
        if (widget.expectedRole.isNotEmpty && widget.expectedRole != role) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['login_failed']! + ' - wrong role')));
        } else {
          // store locally (so we can show logged-in username if needed)
          LocalDB.users.removeWhere((u) => u['email'] == email);
          LocalDB.users.add({'email': email, 'name': data['user']['name'] ?? '', 'role': role, 'token': data['token'] ?? ''});
          // navigate to main
          String userType = role == 'hospital' ? 'Medics' : (role == 'collector' ? 'Government' : 'Public');
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen(userType: userType, languageProvider: widget.languageProvider)));
        }
      } else {
        var data = {};
        try { data = json.decode(res.body); } catch (e) {}
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${t['login_failed']!}: ${data['error'] ?? 'check credentials'}')));
      }
    } catch (e) {
      // offline or server unreachable - check local users
      final local = LocalDB.users.firstWhere((u) => u['email'] == email && u['password'] == pass, orElse: () => {});
      if (local.isNotEmpty) {
        String role = local['role'] ?? 'user';
        String userType = role == 'hospital' ? 'Medics' : (role == 'collector' ? 'Government' : 'Public');
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen(userType: userType, languageProvider: widget.languageProvider)));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['connection_error']!)));
      }
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['login']!)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          DropdownButton<String>(
            value: widget.languageProvider.current,
            items: ['English', 'Hindi', 'Bengali'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => widget.languageProvider.setLanguage(v!)),
          ),
          TextField(controller: emailC, decoration: InputDecoration(labelText: t['email'])),
          const SizedBox(height: 12),
          TextField(controller: passC, obscureText: true, decoration: InputDecoration(labelText: t['password'])),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: loading ? null : login, child: loading ? const CircularProgressIndicator(color: Colors.white) : Text(t['login']!)),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () {
              // open register
              Navigator.push(context, MaterialPageRoute(builder: (_) => RegisterScreen(expectedRole: widget.expectedRole, languageProvider: widget.languageProvider)));
            },
            child: Text(widget.languageProvider.t['register']!),
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () {
              // public without login
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen(userType: 'Public', languageProvider: widget.languageProvider)));
            },
            child: Text(widget.languageProvider.t['continue_public']!),
          ),
        ]),
      ),
    );
  }
}

class RegisterScreen extends StatefulWidget {
  final String expectedRole;
  final LanguageProvider languageProvider;
  const RegisterScreen({super.key, required this.expectedRole, required this.languageProvider});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController nameC = TextEditingController();
  final TextEditingController emailC = TextEditingController();
  final TextEditingController passC = TextEditingController();
  bool loading = false;

  Future<void> register() async {
    final t = widget.languageProvider.t;
    final name = nameC.text.trim();
    final email = emailC.text.trim();
    final pass = passC.text;

    if (name.isEmpty || email.isEmpty || pass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['fill_fields']!)));
      return;
    }

    // enforce prefix rules for medics/government registrations if expectedRole specified.
    if (widget.expectedRole == 'hospital' && !email.startsWith('MI')) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: const Text('Medic emails must start with MI')));
      return;
    }
    if (widget.expectedRole == 'collector' && !email.startsWith('GI')) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: const Text('Government emails must start with GI')));
      return;
    }
    if (widget.expectedRole.isEmpty && !email.startsWith('UI')) {
      // public fallback
      // allow UI prefix or enforce?
    }

    setState(() => loading = true);
    try {
      final url = Uri.parse('$BASE_URL/api/auth/register');
      final res = await http.post(url,
          headers: {'Content-Type': 'application/json'},
          body: json.encode({'name': name, 'email': email, 'password': pass}));
      if (res.statusCode == 200 || res.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['register_success']!)));
        // store locally too as fallback
        LocalDB.users.add({'email': email, 'password': pass, 'role': widget.expectedRole.isNotEmpty ? widget.expectedRole : 'user', 'name': name});
        Navigator.pop(context);
      } else {
        final data = json.decode(res.body);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${t['register_failed']!}: ${data['error'] ?? 'error'}')));
      }
    } catch (e) {
      // fallback: store locally (for demo)
      LocalDB.users.add({'email': email, 'password': pass, 'role': widget.expectedRole.isNotEmpty ? widget.expectedRole : 'user', 'name': name});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${t['register_success']} (local fallback)')));
      Navigator.pop(context);
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['register']!)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: nameC, decoration: InputDecoration(labelText: t['name'])),
          const SizedBox(height: 8),
          TextField(controller: emailC, decoration: InputDecoration(labelText: t['email'])),
          const SizedBox(height: 8),
          TextField(controller: passC, decoration: InputDecoration(labelText: t['password']), obscureText: true),
          const SizedBox(height: 12),
          Text(t['signup_role_hint']!, style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: loading ? null : register, child: loading ? const CircularProgressIndicator(color: Colors.white) : Text(t['register']!))
        ]),
      ),
    );
  }
}

// ----------- MAIN SCREEN (Public / Medics / Government Support) -----------
class MainScreen extends StatefulWidget {
  final String userType; // 'Public', 'Medics', 'Government'
  final LanguageProvider languageProvider;

  const MainScreen({
    super.key,
    required this.userType,
    required this.languageProvider,
  });

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final lang = widget.languageProvider;

    // -----------------------------
    //           SCREENS
    // -----------------------------
    final List<Widget> screens = widget.userType == 'Public'
        ? [
            PublicHome(languageProvider: lang),
            ChatScreen(),
          ]
        : widget.userType == 'Medics'
            ? [
                MedicsHome(languageProvider: lang),
                ProfileScreen(languageProvider: lang),
              ]
            : [
                GovernmentHome(languageProvider: lang),
                ProfileScreen(languageProvider: lang),
              ];

    // -----------------------------
    //        BOTTOM NAV ITEMS
    // -----------------------------
    final items = widget.userType == 'Public'
        ? [
            BottomNavigationBarItem(
              icon: const Icon(Icons.home),
              label: lang.t['home'],
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.chat),
              label: lang.t['chatbot'],
            ),
          ]
        : widget.userType == 'Medics'
            ? [
                BottomNavigationBarItem(
                  icon: const Icon(Icons.medical_services),
                  label: lang.t['medic'],
                ),
                BottomNavigationBarItem(
                  icon: const Icon(Icons.person),
                  label: lang.t['profile'],
                ),
              ]
            : [
                BottomNavigationBarItem(
                  icon: const Icon(Icons.account_balance),
                  label: lang.t['government'],
                ),
                BottomNavigationBarItem(
                  icon: const Icon(Icons.person),
                  label: lang.t['profile'],
                ),
              ];

    // -----------------------------
    //             UI
    // -----------------------------
    return Scaffold(
      body: screens[index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        items: items,
        onTap: (i) => setState(() => index = i),
        selectedItemColor: const Color(0xFF0891B2),
      ),
    );
  }
}

// ---------- PUBLIC HOME ----------
class PublicHome extends StatefulWidget {
  final LanguageProvider languageProvider;
  const PublicHome({super.key, required this.languageProvider});

  @override
  State<PublicHome> createState() => _PublicHomeState();
}

class _PublicHomeState extends State<PublicHome> {
  List<Map<String, dynamic>> ads = [];
  @override
  void initState() {
    super.initState();
    fetchAds();
  }

  Future<void> fetchAds() async {
    final langCode = widget.languageProvider.current == 'Hindi' ? 'hi' : (widget.languageProvider.current == 'Bengali' ? 'bn' : 'en');
    try {
      final url = Uri.parse('$BASE_URL/api/user/schemes?lang=$langCode');
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        final list = (data['schemes'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
        setState(() => ads = list);
        // update local fallback as well
        LocalDB.ads = ads;
        return;
      }
    } catch (e) {
      // server unreachable -> fallback
    }
    setState(() => ads = LocalDB.ads.map((ad) => Map<String, dynamic>.from(ad)).toList());
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    return Scaffold(
      appBar: AppBar(
        title: Text(t['app_name']!),
        actions: [
          IconButton(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const InterfaceChoiceScreen())), icon: const Icon(Icons.home)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.arrow_back),
        label: Text(widget.languageProvider.t['return_home']!),
        onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const InterfaceChoiceScreen())),
      ),
      body: RefreshIndicator(
        onRefresh: fetchAds,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(t['ads']!, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (ads.isEmpty) const Text('No advertisements yet'),
            ...ads.map((ad) => Card(
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    title: Text(ad['title'] ?? ''),
                    subtitle: Text(ad['description'] ?? ''),
                  ),
                )),
            const SizedBox(height: 20),
            Text(t['good_habits_title']!, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            for (int i = 1; i <= 5; i++) Card(margin: const EdgeInsets.symmetric(vertical: 6), child: ListTile(leading: const Icon(Icons.water_drop), title: Text(t['habit$i']!))),
            const SizedBox(height: 30),
            ListTile(
              leading: const Icon(Icons.notifications),
              title: Text(t['alerts']!),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => AlertsScreen(languageProvider: widget.languageProvider)));
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ---------- Chatbot Coming Soon (Public only) ----------
class ChatbotComingSoon extends StatelessWidget {
  final LanguageProvider languageProvider;
  const ChatbotComingSoon({super.key, required this.languageProvider});

  @override
  Widget build(BuildContext context) {
    final t = languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['chatbot']!)),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.smart_toy, size: 100, color: Color(0xFF0891B2)),
          const SizedBox(height: 16),
          Text(t['coming_soon']!, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 24), child: Text('Get ready for AI-based water health assistance!', textAlign: TextAlign.center)),
        ]),
      ),
    );
  }
}

// ---------- MEDICS HOME (small landing) ----------
class MedicsHome extends StatelessWidget {
  final LanguageProvider languageProvider;
  const MedicsHome({super.key, required this.languageProvider});

  @override
  Widget build(BuildContext context) {
    final t = languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['medics']!)),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(child: ListTile(title: Text(t['report_case']!), leading: const Icon(Icons.report), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReportCaseScreen(languageProvider: languageProvider))))),
        Card(child: ListTile(title: Text(t['post_ad']!), leading: const Icon(Icons.campaign), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PostAdScreen(languageProvider: languageProvider))))),
        Card(child: ListTile(title: Text(t['ask_help']!), leading: const Icon(Icons.help), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AskHelpScreen(languageProvider: languageProvider))))),
        Card(child: ListTile(title: Text(t['show_allocated']!), leading: const Icon(Icons.list_alt), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShowAllocatedScreen(languageProvider: languageProvider))))),
        Card(child: ListTile(title: Text(t['alerts']!), leading: const Icon(Icons.notifications), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AlertsScreen(languageProvider: languageProvider))))),
        const SizedBox(height: 20),
        ElevatedButton.icon(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const InterfaceChoiceScreen())), icon: const Icon(Icons.logout), label: Text(t['logout']!)),
      ]),
    );
  }
}

// ---------- MEDICS PORTAL PAGES ----------
class ReportCaseScreen extends StatefulWidget {
  final LanguageProvider languageProvider;
  const ReportCaseScreen({super.key, required this.languageProvider});

  @override
  State<ReportCaseScreen> createState() => _ReportCaseScreenState();
}

class _ReportCaseScreenState extends State<ReportCaseScreen> {
  final TextEditingController villageC = TextEditingController();
  final TextEditingController countC = TextEditingController();

  Future<void> submit() async {
    final t = widget.languageProvider.t;
    final v = villageC.text.trim();
    final c = int.tryParse(countC.text.trim()) ?? 0;
    if (v.isEmpty || c <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['fill_fields']!)));
      return;
    }
    // attempt backend POST (if authenticated you'd pass token; for demo we simply POST without auth or store local)
    try {
      final url = Uri.parse('$BASE_URL/api/medics/report-case');
      // in real flow, you'd pass Authorization header with token. For demo backend likely rejects; fallback to local.
      final res = await http.post(url, headers: {'Content-Type': 'application/json'}, body: json.encode({'name': 'unknown', 'age': 0, 'village_id': 0, 'disease': 'unknown'}));
      if (res.statusCode == 200) {
        // server recorded case - ideally server returns patient id and details; we still add to local visible cases
        LocalDB.cases.add({'village': v, 'count': c, 'reportedBy': 'MI', 'timestamp': DateTime.now()});
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['case_reported']!)));
      } else {
        LocalDB.cases.add({'village': v, 'count': c, 'reportedBy': 'MI', 'timestamp': DateTime.now()});
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['case_reported']!)));
      }
    } catch (e) {
      // fallback
      LocalDB.cases.add({'village': v, 'count': c, 'reportedBy': 'MI', 'timestamp': DateTime.now()});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['case_reported']!)));
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['report_case']!)),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          TextField(controller: villageC, decoration: InputDecoration(labelText: 'Village')),
          const SizedBox(height: 8),
          TextField(controller: countC, decoration: InputDecoration(labelText: 'Number of cases'), keyboardType: TextInputType.number),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: submit, child: Text(t['send']!))
        ]),
      ),
    );
  }
}

class PostAdScreen extends StatefulWidget {
  final LanguageProvider languageProvider;
  const PostAdScreen({super.key, required this.languageProvider});

  @override
  State<PostAdScreen> createState() => _PostAdScreenState();
}

class _PostAdScreenState extends State<PostAdScreen> {
  final TextEditingController hospitalC = TextEditingController();
  final TextEditingController driveC = TextEditingController();
  final TextEditingController villageC = TextEditingController();

  Future<void> submit() async {
    final t = widget.languageProvider.t;
    final h = hospitalC.text.trim();
    final d = driveC.text.trim();
    final v = villageC.text.trim();
    if (h.isEmpty || d.isEmpty || v.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['fill_fields']!)));
      return;
    }
    final payload = {'title': h + ' - ' + d, 'description': 'Drive at $v', 'village': v};
    try {
      // try backend (endpoint varies across setups). Many earlier server versions used /ads or /api/medics/*.
      final url = Uri.parse('$BASE_URL/ads'); // try original ads endpoint
      final res = await http.post(url, headers: {'Content-Type': 'application/json'}, body: json.encode(payload));
      if (res.statusCode == 200) {
        LocalDB.ads.add({'title': payload['title'], 'description': payload['description']});
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['ad_posted']!)));
      } else {
        LocalDB.ads.add({'title': payload['title'], 'description': payload['description']});
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['ad_posted']!)));
      }
    } catch (e) {
      LocalDB.ads.add({'title': payload['title'], 'description': payload['description']});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['ad_posted']!)));
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['post_ad']!)),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          TextField(controller: hospitalC, decoration: InputDecoration(labelText: 'Hospital name')),
          const SizedBox(height: 8),
          TextField(controller: driveC, decoration: InputDecoration(labelText: 'Drive / Campaign name')),
          const SizedBox(height: 8),
          TextField(controller: villageC, decoration: InputDecoration(labelText: 'Village')),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: submit, child: Text(t['send']!))
        ]),
      ),
    );
  }
}

class AskHelpScreen extends StatefulWidget {
  final LanguageProvider languageProvider;
  const AskHelpScreen({super.key, required this.languageProvider});

  @override
  State<AskHelpScreen> createState() => _AskHelpScreenState();
}

class _AskHelpScreenState extends State<AskHelpScreen> {
  final TextEditingController reqC = TextEditingController();
  bool sending = false;

  Future<void> send() async {
    final t = widget.languageProvider.t;
    final msg = reqC.text.trim();
    if (msg.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['fill_fields']!)));
      return;
    }
    setState(() => sending = true);
    try {
      final url = Uri.parse('$BASE_URL/api/medics/request');
      // this endpoint requires auth; for demo we post without auth and also add to local fallback
      final res = await http.post(url, headers: {'Content-Type': 'application/json'}, body: json.encode({'village_id': 0, 'type': 'resource', 'details': msg}));
      if (res.statusCode == 200) {
        LocalDB.resourceRequests.add({'id': 'req-${LocalDB.resourceRequests.length + 1}', 'from': 'MI', 'message': msg, 'status': 'pending', 'timestamp': DateTime.now()});
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['request_sent']!)));
      } else {
        LocalDB.resourceRequests.add({'id': 'req-${LocalDB.resourceRequests.length + 1}', 'from': 'MI', 'message': msg, 'status': 'pending', 'timestamp': DateTime.now()});
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['request_sent']!)));
      }
    } catch (e) {
      LocalDB.resourceRequests.add({'id': 'req-${LocalDB.resourceRequests.length + 1}', 'from': 'MI', 'message': msg, 'status': 'pending', 'timestamp': DateTime.now()});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['request_sent']!)));
    } finally {
      setState(() => sending = false);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['ask_help']!)),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          const SizedBox(height: 8),
          const Text('Ask for help'),
          const SizedBox(height: 8),
          TextField(controller: reqC, maxLines: 4, decoration: InputDecoration(hintText: 'Write request')),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: sending ? null : send, child: Text(t['send']!))
        ]),
      ),
    );
  }
}

class ShowAllocatedScreen extends StatefulWidget {
  final LanguageProvider languageProvider;
  const ShowAllocatedScreen({super.key, required this.languageProvider});

  @override
  State<ShowAllocatedScreen> createState() => _ShowAllocatedScreenState();
}

class _ShowAllocatedScreenState extends State<ShowAllocatedScreen> {
  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    final allocs = LocalDB.allocations;
    return Scaffold(
      appBar: AppBar(title: Text(t['show_allocated']!)),
      body: allocs.isEmpty ? Center(child: Text(t['no_allocations']!)) : ListView.builder(
        itemCount: allocs.length,
        itemBuilder: (context, i) {
          final a = allocs[i];
          return Card(child: ListTile(title: Text(a['details'] ?? ''), subtitle: Text('By: ${a['allocatedBy'] ?? ''}')));
        },
      ),
    );
  }
}

// Alerts shared across public/medics (set by government)
class AlertsScreen extends StatefulWidget {
  final LanguageProvider languageProvider;
  const AlertsScreen({super.key, required this.languageProvider});

  @override
  State<AlertsScreen> createState() => _AlertsScreenState();
}
class _AlertsScreenState extends State<AlertsScreen> {
  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    final alerts = LocalDB.alerts.reversed.toList(); // newest first
    return Scaffold(
      appBar: AppBar(title: Text(t['alerts']!)),
      body: alerts.isEmpty ? Center(child: Text('No alerts')) : ListView.builder(
        itemCount: alerts.length,
        itemBuilder: (context, i) {
          final a = alerts[i];
          return Card(child: ListTile(title: Text(a['message'] ?? ''), subtitle: Text(a['timestamp']?.toString() ?? '')));
        },
      ),
    );
  }
}

// ---------- GOVERNMENT HOME ----------
class GovernmentHome extends StatelessWidget {
  final LanguageProvider languageProvider;
  const GovernmentHome({super.key, required this.languageProvider});

  @override
  Widget build(BuildContext context) {
    final t = languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['government']!)),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(child: ListTile(title: Text(t['trend_analysis']!), leading: const Icon(Icons.show_chart), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TrendAnalysisScreen(languageProvider: languageProvider))))),
        Card(child: ListTile(title: Text(t['emergency_gen']!), leading: const Icon(Icons.campaign), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => EmergencyGeneratorScreen(languageProvider: languageProvider))))),
        Card(child: ListTile(title: Text(t['resource_allocation']!), leading: const Icon(Icons.inventory), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ResourceAllocationScreen(languageProvider: languageProvider))))),
        Card(child: ListTile(title: Text(t['patient_distribution']!), leading: const Icon(Icons.map), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PatientDistributionScreen(languageProvider: languageProvider))))),
        Card(child: ListTile(title: Text(t['water_test_results']!), leading: const Icon(Icons.water), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WaterTestResultsScreen(languageProvider: languageProvider))))),
        const SizedBox(height: 20),
        ElevatedButton.icon(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const InterfaceChoiceScreen())), icon: const Icon(Icons.logout), label: Text(t['logout']!))
      ]),
    );
  }
}

// ---------- GOVERNMENT PAGES ----------
class TrendAnalysisScreen extends StatelessWidget {
  final LanguageProvider languageProvider;
  const TrendAnalysisScreen({super.key, required this.languageProvider});

  @override
  Widget build(BuildContext context) {
    final t = languageProvider.t;
    final cases = List<Map<String,dynamic>>.from(LocalDB.cases);
    cases.sort((a,b) {
      final ta = a['timestamp'] as DateTime? ?? DateTime.now();
      final tb = b['timestamp'] as DateTime? ?? DateTime.now();
      return tb.compareTo(ta);
    });
    return Scaffold(
      appBar: AppBar(title: Text(t['trend_analysis']!)),
      body: cases.isEmpty ? Center(child: Text(t['no_cases']!)) : ListView.builder(
        itemCount: cases.length,
        itemBuilder: (context, i) {
          final c = cases[i];
          return ListTile(title: Text('${c['village']}'), subtitle: Text('Count: ${c['count']} • ${c['reportedBy']}'), trailing: Text(c['timestamp'] != null ? (c['timestamp'] as DateTime).toString() : ''));
        },
      ),
    );
  }
}

class EmergencyGeneratorScreen extends StatefulWidget {
  final LanguageProvider languageProvider;
  const EmergencyGeneratorScreen({super.key, required this.languageProvider});

  @override
  State<EmergencyGeneratorScreen> createState() => _EmergencyGeneratorScreenState();
}
class _EmergencyGeneratorScreenState extends State<EmergencyGeneratorScreen> {
  final TextEditingController msgC = TextEditingController();
  bool sending = false;

  Future<void> send() async {
    final t = widget.languageProvider.t;
    final msg = msgC.text.trim();
    if (msg.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['fill_fields']!))); return; }
    setState(() => sending = true);
    try {
      final url = Uri.parse('$BASE_URL/alerts');
      final res = await http.post(url, headers: {'Content-Type': 'application/json'}, body: json.encode({'message': msg}));
      LocalDB.alerts.add({'id': 'a-${LocalDB.alerts.length+1}', 'message': msg, 'timestamp': DateTime.now()});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Alert sent')));
    } catch (e) {
      LocalDB.alerts.add({'id': 'a-${LocalDB.alerts.length+1}', 'message': msg, 'timestamp': DateTime.now()});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Alert queued (local)')));
    } finally {
      setState(() => sending = false);
      msgC.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['emergency_gen']!)),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          TextField(controller: msgC, maxLines: 4, decoration: InputDecoration(hintText: 'Enter alert message')),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: sending?null:send, child: Text(t['send']!))
        ]),
      ),
    );
  }
}

class ResourceAllocationScreen extends StatefulWidget {
  final LanguageProvider languageProvider;
  const ResourceAllocationScreen({super.key, required this.languageProvider});

  @override
  State<ResourceAllocationScreen> createState() => _ResourceAllocationScreenState();
}
class _ResourceAllocationScreenState extends State<ResourceAllocationScreen> {
  List pending = [];

  @override
  void initState() {
    super.initState();
    loadPending();
  }

  void loadPending() async {
    // use local DB for demo
    setState(() => pending = LocalDB.resourceRequests.where((r) => r['status'] == 'pending').toList());
  }

  void allot(Map req) async {
    // create allocation and mark request
    final allocation = {'requestId': req['id'], 'details': 'Allocated for: ${req['message']}', 'allocatedBy': 'GI', 'timestamp': DateTime.now()};
    LocalDB.allocations.add(allocation);
    final idx = LocalDB.resourceRequests.indexWhere((r) => r['id'] == req['id']);
    if (idx >= 0) LocalDB.resourceRequests[idx]['status'] = 'allotted';
    setState(() => pending = LocalDB.resourceRequests.where((r) => r['status'] == 'pending').toList());
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(widget.languageProvider.t['help_allocated']!)));
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['resource_allocation']!)),
      body: pending.isEmpty ? Center(child: Text(t['no_requests']!)) : ListView.builder(
        itemCount: pending.length,
        itemBuilder: (context, i) {
          final r = pending[i];
          return Card(child: ListTile(title: Text(r['message'] ?? ''), subtitle: Text('From: ${r['from']}'), trailing: ElevatedButton(onPressed: ()=>allot(r), child: Text('Allot'))));
        },
      ),
    );
  }
}

class PatientDistributionScreen extends StatelessWidget {
  final LanguageProvider languageProvider;
  const PatientDistributionScreen({super.key, required this.languageProvider});

  @override
  Widget build(BuildContext context) {
    final t = languageProvider.t;
    final Map<String,int> byVillage = {};
    for (var c in LocalDB.cases) {
      final v = c['village'] ?? 'Unknown';
      byVillage[v] = (byVillage[v] ?? 0) + (c['count'] as int? ?? 0);
    }
    return Scaffold(
      appBar: AppBar(title: Text(t['patient_distribution']!)),
      body: byVillage.isEmpty ? Center(child: Text(t['no_cases']!)) : ListView(children: byVillage.entries.map((e)=>ListTile(title: Text(e.key), trailing: Text('${e.value}'))).toList()),
    );
  }
}

class WaterTestResultsScreen extends StatelessWidget {
  final LanguageProvider languageProvider;
  const WaterTestResultsScreen({super.key, required this.languageProvider});
  @override
  Widget build(BuildContext context) {
    final t = languageProvider.t;
    return Scaffold(appBar: AppBar(title: Text(t['water_test_results']!)), body: const Center(child: Text('Upload test results from DB')) );
  }
}

// ---------- PROFILE ----------
class ProfileScreen extends StatelessWidget {
  final LanguageProvider languageProvider;
  const ProfileScreen({super.key, required this.languageProvider});

  @override
  Widget build(BuildContext context) {
    final t = languageProvider.t;
    return Scaffold(
      appBar: AppBar(title: Text(t['profile']!)),
      body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text('Profile area (demo)'),
        const SizedBox(height: 12),
        ElevatedButton.icon(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const InterfaceChoiceScreen())), icon: const Icon(Icons.logout), label: Text(t['logout']!))
      ])),
    );
  }
}

// ----------------------------------------------------
// MEDICS PORTAL (Placeholder)
// ----------------------------------------------------
class MedicsPortal extends StatelessWidget {
  final LanguageProvider languageProvider;
  const MedicsPortal({super.key, required this.languageProvider});

  @override
  Widget build(BuildContext context) {
    final t = languageProvider.translations;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0891B2),
        title: Text(t['medics'] ?? "Medics Portal"),
      ),
      body: const Center(
        child: Text(
          "Medics Portal - Coming Soon",
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}

// ----------------------------------------------------
// GOVERNMENT PORTAL (Placeholder)
// ----------------------------------------------------
class GovernmentPortal extends StatelessWidget {
  final LanguageProvider languageProvider;
  const GovernmentPortal({super.key, required this.languageProvider});

  @override
  Widget build(BuildContext context) {
    final t = languageProvider.translations;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0891B2),
        title: Text(t['government'] ?? "Government Portal"),
      ),
      body: const Center(
        child: Text(
          "Government Portal - Coming Soon",
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}

