import 'dart:convert';
import 'package:http/http.dart' as http;

class ChatService {
  static const String baseUrl = "http://127.0.0.1:5000/chat";


static Future<String> sendMessage(String message) async {
  try {
    final uri = Uri.parse("$baseUrl/chat");  // FIXED

    final response = await http.post(
      uri,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"message": message}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body)["reply"];
    } else {
      return "Server error: ${response.statusCode}";
    }
  } catch (e) {
    return "Error: $e";
  }
}
}
