import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = "http://192.168.29.87:4000";

  static Future<String> getBotResponse(String msg) async {
    final url = Uri.parse("$baseUrl/chat");

    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"message": msg}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body)["response"];
    } else {
      return "Server error: ${response.statusCode}";
    }
  }
}
