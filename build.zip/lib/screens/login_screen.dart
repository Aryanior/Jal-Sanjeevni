import 'package:flutter/material.dart';
import 'package:my_app/screens/user_dashboard.dart';
import 'package:my_app/screens/medics_portal.dart';
import 'package:my_app/screens/government_dashboard.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _idController = TextEditingController();
  String? _errorText;

  void _handleLogin() {
    final id = _idController.text.trim();

    if (id.startsWith('UI')) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const UserDashboard()),
      );
    } else if (id.startsWith('MI')) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MedicsPortal()),
      );
    } else if (id.startsWith('GI')) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const GovernmentDashboard()),
      );
    } else {
      setState(() {
        _errorText = 'Incorrect ID. Please start with UI, MI, or GI.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Jal Sanjeevni Login')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _idController,
              decoration: InputDecoration(
                labelText: 'Enter User ID',
                errorText: _errorText,
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _handleLogin,
              child: const Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}
