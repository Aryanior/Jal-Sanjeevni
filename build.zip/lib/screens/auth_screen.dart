import 'package:flutter/material.dart';
import 'api/auth_api.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isLogin = true;
  final _emailC = TextEditingController();
  final _passC = TextEditingController();
  final _nameC = TextEditingController();
  String _status = '';

  void _switch() => setState(() { _isLogin = !_isLogin; _status = ''; });

  Future<void> _submit() async {
    final email = _emailC.text.trim();
    final pass = _passC.text.trim();
    final name = _nameC.text.trim();
    if (_isLogin) {
      if (email.isEmpty || pass.isEmpty) { setState(() => _status = 'Fill fields'); return; }
      setState(() => _status = 'Logging in...');
      try {
        final res = await apiLogin(email, pass);
        if (res.containsKey('token')) {
          // successful: store token as needed — here we just navigate to public home
          // NOTE: you may want to save token to secure storage for subsequent requests
          Navigator.pushReplacementNamed(context, '/home'); // or pass user info
        } else {
          setState(() => _status = res['error'] ?? 'Login failed');
        }
      } catch (e) {
        setState(() => _status = 'Network error');
      }
    } else {
      // signup
      if (name.isEmpty || email.isEmpty || pass.isEmpty) { setState(() => _status = 'Fill fields'); return; }
      setState(() => _status = 'Registering...');
      try {
        final res = await apiRegister(name, email, pass);
        if (res['ok'] == true) {
          setState(() => _status = 'Registered — please login');
          // optionally auto-login here
          _switch();
        } else {
          setState(() => _status = res['error'] ?? 'Register failed');
        }
      } catch (e) {
        setState(() => _status = 'Network error');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isLogin ? 'Login' : 'Sign Up')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            if (!_isLogin) TextField(controller: _nameC, decoration: const InputDecoration(labelText: 'Full name')),
            TextField(controller: _emailC, decoration: const InputDecoration(labelText: 'Email')),
            TextField(controller: _passC, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: _submit, child: Text(_isLogin ? 'Login' : 'Create account')),
            const SizedBox(height: 12),
            TextButton(onPressed: _switch, child: Text(_isLogin ? 'Create new account' : 'Back to login')),
            const SizedBox(height: 12),
            Text(_status, style: const TextStyle(color: Colors.red)),
          ],
        ),
      ),
    );
  }
}
