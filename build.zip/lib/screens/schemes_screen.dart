import 'package:flutter/material.dart';
import '../services/api_service.dart';

class SchemesScreen extends StatefulWidget {
  const SchemesScreen({super.key});

  @override
  State<SchemesScreen> createState() => _SchemesScreenState();
}

class _SchemesScreenState extends State<SchemesScreen> {
  late Future<List<dynamic>> schemes;

  @override
  void initState() {
    super.initState();
    schemes = ApiService.fetchSchemes(); // call API when screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gov Schemes')),
      body: FutureBuilder<List<dynamic>>(
        future: schemes,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No schemes found'));
          }

          final data = snapshot.data!;
          return ListView.builder(
            itemCount: data.length,
            itemBuilder: (context, index) {
              final scheme = data[index];
              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  title: Text(scheme['name']),
                  subtitle: Text('Village: ${scheme['village']}'),
                  trailing: Text('${scheme['start']} → ${scheme['end']}'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
