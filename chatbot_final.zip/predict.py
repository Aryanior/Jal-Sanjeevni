import sys
import pickle
import json

# Load the model + vectorizer
vectorizer = pickle.load(open("tfidf_vectorizer.pkl", "rb"))
model = pickle.load(open("chatbot_model.pkl", "rb"))

# Read question from Node
input_text = sys.argv[1]

# Vectorize + predict
X = vectorizer.transform([input_text])
prediction = model.predict(X)[0]

# Return answer
print(json.dumps({"answer": prediction}))
